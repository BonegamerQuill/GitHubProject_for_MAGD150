let x = 200;
let y = 200;
let cursorSize = 20;
let cursorSetting = 0;

function setup() {
  createCanvas(400, 400);
  background(220);
  frameRate(60);
}

function mouseClicked() {
  if (cursorSize == 20) {
    fill(cursorSetting);
    circle(x, y, cursorSize);
    cursorSize = 5;
    fill(255);
  } else if (cursorSize == 5) {
    cursorSize = 10;
  } else if (cursorSize == 10) {
    cursorSize = 20;
  }
}

function draw() {
  if (keyIsPressed) {
  	if (key == 'w') {
  		y=y-1;
  	} else if (key == 'a') {
  		x=x-1;
  	} else if (key == 's') {
  		y=y+1;
  	} else if (key == 'd') {
  		x=x+1;
  	} else if (key == 'c') {
      background(220);
  	} else if (key == 'r') {
      x = 200;
      y = 200;
  	} else if (key == 'e') {
      cursorSetting = 220;
  	} else if (key == 'x') {
      cursorSetting = 0;
  	}
  }

  if (keyIsPressed) {
    if (key == 'q') {
      for (let i = 0; i < 50; i++) {
        x=x+1;
        y=y+1;
        circle(x, y, cursorSize);
      }
      for (let i = 0; i < 50; i++) {
        x=x+1;
        y=y-1;
        circle(x, y, cursorSize);
      }
      for (let i = 0; i < 50; i++) {
        x=x-1;
        y=y-1;
        circle(x, y, cursorSize);
      }
      for (let i = 0; i < 50; i++) {
        x=x-1;
        y=y+1;
        circle(x, y, cursorSize);
      }
    }
  }

  stroke(cursorSetting);
  circle(x, y, cursorSize);
}