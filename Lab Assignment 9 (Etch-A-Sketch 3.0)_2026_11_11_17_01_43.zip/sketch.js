let x = 350;
let y = 210;
let cursorSize = 10;
let cursorSetting = 0;
let val = 0;

let drawButton = new Button("box", 150, 420);
drawButton.width = 180;
drawButton.height = 50;

drawButton.onPress = function() {
  cursorSetting = 0;
}

let eraseButton = new Button("box", 150, 490);
eraseButton.width = 180;
eraseButton.height = 50;

eraseButton.onPress = function() {
  cursorSetting = 220;
}

let clearAllButton = new Button("box", 370, 420);
clearAllButton.width = 180;
clearAllButton.height = 50;

clearAllButton.onPressBegin = function() {
  background(220);
}

let sizeSlider = new Slider("circle", false, 385, 510);
sizeSlider.smooth = false;
sizeSlider.Slength = 150;
sizeSlider.segments = 6;
sizeSlider.fill = (0, 0, 0);
sizeSlider.stroke = (255, 255, 255);

sizeSlider.onValueChange = function(deltaValue) {
  if (deltaValue == 1) {
    val++;
  } else if (deltaValue == -1) {
    val--;
  }
  
  if (val == 0) {
    fill(cursorSetting, cursorSetting, cursorSetting);
    circle(x, y, cursorSize);
    cursorSize = 2.5;
    fill(255, 255, 255);
  } else if (val == 1) {
    fill(cursorSetting, cursorSetting, cursorSetting);
    circle(x, y, cursorSize);
    cursorSize = 5;
    fill(255, 255, 255);
  } else if (val == 2) {
    fill(cursorSetting, cursorSetting, cursorSetting);
    circle(x, y, cursorSize);
    cursorSize = 10;
    fill(255, 255, 255);
  } else if (val == 3) {
    fill(cursorSetting, cursorSetting, cursorSetting);
    circle(x, y, cursorSize);
    cursorSize = 20;
    fill(255, 255, 255);
  } else if (val == 4) {
    fill(cursorSetting, cursorSetting, cursorSetting);
    circle(x, y, cursorSize);
    cursorSize = 30;
    fill(255, 255, 255);
  } else if (val == 5) {
    fill(cursorSetting, cursorSetting, cursorSetting);
    circle(x, y, cursorSize);
    cursorSize = 40;
    fill(255, 255, 255);
  } else if (val == 6) {
    cursorSize = 50;
  }
}

let xDial = new Dial(true, 70, 480);
xDial.radius = 50;
xDial.segments = 10;

xDial.onValueChange = function(deltaValue) {
  x = x + deltaValue;
}

let yDial = new Dial(true, 630, 480);
yDial.radius = 50;
yDial.segments = 10;

yDial.onValueChange = function(deltaValue) {
  y = y + deltaValue;
}

function setup() {
  createCanvas(700, 550);
  colorMode(RGB, 255, 255, 255, 1);
  background(220, 220, 220);
}

function draw() {
  if (keyIsPressed) {
  	if (key == 'w') {
  		y=y-1;
  	} else if (key == 'a') {
  		x=x-1;
  	} else if (key == 's') {
  		y=y+1;
  	} else if (key == 'd') {
  		x=x+1;
  	}
  }

  if (x < 10){
    x = 10;
  } else if (x > 690) {
    x = 690;
  } else if (y < 10) {
    y = 10;
  } else if (y > 410) {
    y = 410;
  }
  
  fill(255, 255, 255);
  stroke(cursorSetting, cursorSetting, cursorSetting);
  circle(x, y, cursorSize);

  fill(255, 0, 0);
  stroke(0, 0, 0);
  beginShape();
    vertex(0, 0);
    vertex(0, 550);
    vertex(700, 550);
    vertex(700, 0);
    beginContour();
      vertex(10, 10);
      vertex(690, 10);
      vertex(690, 410);
      vertex(10, 410);
      vertex(10, 10);
    endContour();
  endShape(CLOSE);
}