let x = 250;
let y = 210;
let cursorSize = 10;
let cursorSetting = 0;

function setup() {
  createCanvas(500, 550);
  colorMode(RGB, 255, 255, 255, 1);
  background(220, 220, 220);
  ellipseMode(RADIUS);
}

/*
Note: Yes, this is basically my submission for the previous lab,
only modified to fit the parameters of this lab assignment.
Movement of the cursor is still mapped to WASD on its own, as while
it could be possible to implement buttons for it, it just seemed too tedious,
and the other functions would already fulfill the criteria for this
lab assignment on their own. There is also no recenter cursor function,
as I added code to ensure the cursor cannot leave the bounds of the "screen",
or the "create diamond" function.
*/

function mousePressed() {
	if ((mouseX > 170) && (mouseX < 170+180) && (mouseY > 420) && (mouseY < 420+50)) {
      cursorSetting = 0;
    } else if ((mouseX > 170) && (mouseX < 170+180) && (mouseY > 490) && (mouseY < 490+50)) {
      cursorSetting = 220;
    } else if (dist(mouseX, mouseY, 50, 500) < 20) {
      cursorSize = 20;
    } else if (dist(mouseX, mouseY, 90, 500) < 10) {
      fill(cursorSetting, cursorSetting, cursorSetting);
      circle(x, y, cursorSize);
      cursorSize = 10;
      fill(255, 255, 255);
    } else if (dist(mouseX, mouseY, 115, 500) < 5) {
      fill(cursorSetting, cursorSetting, cursorSetting);
      circle(x, y, cursorSize);
      cursorSize = 5;
      fill(255, 255, 255);
    } else if (dist(mouseX, mouseY, 130, 500) < 2.5) {
      fill(cursorSetting, cursorSetting, cursorSetting);
      circle(x, y, cursorSize);
      cursorSize = 2.5;
      fill(255, 255, 255);
    }
  
}

function draw() {
  if (keyIsPressed) {
  	if (key == 'w') {
  		y=y-1;
  	} else if (key == 'a') {
  		x=x-1;
  	} else if (key == 's') {
  		y=y+1;
  	} else if (key == 'd') {
  		x=x+1;
  	} else if (key == 'c') {
    	if ((mouseX > 370) && (mouseX < 370+120) && (mouseY > 420) && (mouseY < 420+120)) {
          background(220);
        }
  	}
  }

  if (x < 10){
    x = 10;
  } else if (x > 490) {
    x = 490;
  } else if (y < 10) {
    y = 10;
  } else if (y > 410) {
    y = 410;
  }
  
  fill(255, 255, 255);
  stroke(cursorSetting, cursorSetting, cursorSetting);
  circle(x, y, cursorSize);

  fill(255, 0, 0);
  stroke(0, 0, 0);
  beginShape();
    vertex(0, 0);
    vertex(0, 550);
    vertex(500, 550);
    vertex(500, 0);
    beginContour();
      vertex(10, 10);
      vertex(490, 10);
      vertex(490, 410);
      vertex(10, 410);
      vertex(10, 10);
    endContour();
  endShape(CLOSE);

  fill(255, 255, 255);
  ellipse(50, 500, 20, 20);
  ellipse(90, 500, 10, 10);
  ellipse(115, 500, 5, 5);
  ellipse(130, 500, 2.5, 2.5);
  
  fill(180, 180, 180);
  //rect(x, y, w, h);
  rect(170, 420, 180, 50);
  rect(170, 490, 180, 50);
  rect(370, 420, 120);

  fill(0, 0, 0);
  noStroke();
  textSize(35);
  text('Size', 50, 460);
  text('Draw', 220, 460);
  text('Erase', 215, 530);
  text('Clear', 390, 480);
  text('All', 410, 510);
}